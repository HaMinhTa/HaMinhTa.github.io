// Create a reference to Firebase Storage
let storage = firebase.storage();
let storageReference = storage.ref();

storageReference.child('meaningful.jpg').getDownloadURL().then(function(url) {
    let image = new Image();
    image.src = url;
    image.onload = function() {
        draw(this);
    }
}).catch(function(error) {
    console.log(error);
});

function draw(image) {
    let canvas = document.getElementById("mypic");
    let ctx = canvas.getContext("2d");
    ctx.drawImage(image, 0, 0);
    let imageData = ctx.getImageData(0, 0, 700, 525);
    let data = imageData.data;
}